# Correspondences


## Install


"clone" the repository


https://docs.github.com/en/repositories/creating-and-managing-repositories/cloning-a-repository



## Run


on MacOS (x86 NOT xARM), from the "Finder", should be able to double-click "correspondences" in the "bin" directory of the project path
